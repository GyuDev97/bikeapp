package com.bike.trailgo.ui.riding;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.bike.trailgo.R;
import com.bike.trailgo.dto.DangerousArea;
import com.bike.trailgo.net.Server;
import com.bike.trailgo.rideassistant.RideAssistant;
import com.bike.trailgo.setting.RideSettings;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/** Keeps location delivery alive while a ride is active, including in the background. */
public class RideTrackingService extends Service implements LocationListener {
    public static final String ACTION_START = "com.bike.trailgo.action.START_RIDE_TRACKING";
    public static final String ACTION_STOP = "com.bike.trailgo.action.STOP_RIDE_TRACKING";
    public static final String ACTION_PAUSE = "com.bike.trailgo.action.PAUSE_RIDE_ASSISTANT";
    public static final String ACTION_RESUME = "com.bike.trailgo.action.RESUME_RIDE_ASSISTANT";
    public static final String ACTION_COURSE_GUIDANCE = "com.bike.trailgo.action.COURSE_GUIDANCE";
    public static final String ACTION_LOCATION_UPDATE = "com.bike.trailgo.action.RIDE_LOCATION_UPDATE";
    public static final String EXTRA_LOCATION = "ride_location";
    public static final String EXTRA_COURSE_GUIDANCE_MESSAGE = "course_guidance_message";

    private static final String CHANNEL_ID = "ride_tracking";
    private static final int NOTIFICATION_ID = 3102;

    private LocationManager locationManager;
    private RideAssistant rideAssistant;
    private Call<List<DangerousArea>> dangerAreaCall;
    private boolean tracking;
    private SharedPreferences rideSettings;
    private final SharedPreferences.OnSharedPreferenceChangeListener settingsListener = (preferences, key) -> {
        if (RideSettings.KEY_LOCATION_INTERVAL.equals(key) || RideSettings.KEY_BATTERY_SAVER.equals(key)) {
            restartTracking();
        } else if (RideSettings.KEY_VOICE_GUIDE.equals(key) && rideAssistant != null) {
            rideAssistant.setVoiceGuidanceEnabled(RideSettings.isVoiceGuidanceEnabled(this));
        } else if (RideSettings.KEY_DANGER_ALERTS.equals(key) && rideAssistant != null) {
            boolean enabled = RideSettings.areDangerAlertsEnabled(this);
            rideAssistant.setDangerAlertsEnabled(enabled);
            if (enabled) loadDangerAreas();
        }
    };

    public static void start(Context context) {
        Intent intent = new Intent(context, RideTrackingService.class).setAction(ACTION_START);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
    }

    public static void stop(Context context) {
        context.stopService(new Intent(context, RideTrackingService.class));
    }

    public static void pauseAssistant(Context context) {
        sendCommand(context, ACTION_PAUSE);
    }

    public static void resumeAssistant(Context context) {
        sendCommand(context, ACTION_RESUME);
    }

    public static void announceCourseGuidance(Context context, String message) {
        if (message == null || message.trim().isEmpty()) return;
        Intent intent = new Intent(context, RideTrackingService.class)
                .setAction(ACTION_COURSE_GUIDANCE)
                .putExtra(EXTRA_COURSE_GUIDANCE_MESSAGE, message.trim());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent);
        else context.startService(intent);
    }

    private static void sendCommand(Context context, String action) {
        Intent intent = new Intent(context, RideTrackingService.class).setAction(action);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent);
        else context.startService(intent);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        RideSettings.migrate(this);
        rideSettings = RideSettings.preferences(this);
        rideSettings.registerOnSharedPreferenceChangeListener(settingsListener);
        rideAssistant = new RideAssistant(this);
        rideAssistant.setVoiceGuidanceEnabled(RideSettings.isVoiceGuidanceEnabled(this));
        rideAssistant.setDangerAlertsEnabled(RideSettings.areDangerAlertsEnabled(this));
        rideAssistant.start();
        if (RideSettings.areDangerAlertsEnabled(this)) loadDangerAreas();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopTracking();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        // A pause/resume command can also recreate a killed foreground service.  Promote it
        // before handling the command so Android's foreground-service deadline is always met.
        startForeground(NOTIFICATION_ID, buildNotification());
        if (ACTION_PAUSE.equals(action)) {
            rideAssistant.pause(System.currentTimeMillis());
            return START_STICKY;
        }
        if (ACTION_RESUME.equals(action)) {
            rideAssistant.resume(System.currentTimeMillis());
            return START_STICKY;
        }
        if (ACTION_COURSE_GUIDANCE.equals(action)) {
            if (rideAssistant != null) {
                rideAssistant.announceCourseGuidance(intent.getStringExtra(EXTRA_COURSE_GUIDANCE_MESSAGE));
            }
            return START_STICKY;
        }

        RideSessionStore.Snapshot snapshot = RideSessionStore.load(this);
        if (snapshot != null && snapshot.status == 2) {
            rideAssistant.pause(System.currentTimeMillis());
        }
        startTracking();
        // The OS may reclaim this process while the screen is off.  Restarting the foreground
        // service is safer than silently ending an unfinished ride; ACTION_STOP remains explicit.
        return START_STICKY;
    }

    private void startTracking() {
        if (tracking || locationManager == null || !RidePermissionFlow.hasPreciseLocation(this)) {
            return;
        }

        try {
            locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    RideSettings.locationIntervalMillis(this),
                    2f,
                    this
            );
            tracking = true;

            Location lastKnown = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (lastKnown != null) {
                dispatchLocation(lastKnown);
            }
        } catch (SecurityException ignored) {
            stopSelf();
        }
    }

    private void stopTracking() {
        if (locationManager != null && tracking) {
            locationManager.removeUpdates(this);
        }
        tracking = false;
    }

    private void restartTracking() {
        if (!tracking) return;
        stopTracking();
        startTracking();
    }

    @Override
    public void onLocationChanged(Location location) {
        dispatchLocation(location);
    }

    private void dispatchLocation(Location location) {
        if (rideAssistant != null) rideAssistant.onLocation(location);
        Intent update = new Intent(ACTION_LOCATION_UPDATE)
                .setPackage(getPackageName())
                .putExtra(EXTRA_LOCATION, location);
        sendBroadcast(update);
    }

    @Override
    public void onProviderDisabled(String provider) {
        // The activity surfaces GPS availability to the rider.
    }

    @Override
    public void onProviderEnabled(String provider) {
        startTracking();
    }

    @Override
    public void onDestroy() {
        stopTracking();
        if (rideSettings != null) {
            rideSettings.unregisterOnSharedPreferenceChangeListener(settingsListener);
        }
        if (dangerAreaCall != null) dangerAreaCall.cancel();
        if (rideAssistant != null) rideAssistant.shutdown();
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private Notification buildNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.riding_ic_pin)
                .setContentTitle("TrailGo 주행 기록 중")
                .setContentText("백그라운드에서도 위치를 기록하고 있습니다.")
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return;
        }
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "주행 기록",
                NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("TrailGo 주행 중 위치 기록 알림");
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) {
            manager.createNotificationChannel(channel);
        }
    }

    private void loadDangerAreas() {
        if (!RideSettings.areDangerAlertsEnabled(this)) {
            return;
        }
        try {
            dangerAreaCall = Server.getInstance().getApi().getDangerArea();
            dangerAreaCall.enqueue(new Callback<List<DangerousArea>>() {
                @Override
                public void onResponse(Call<List<DangerousArea>> call, Response<List<DangerousArea>> response) {
                    if (response.isSuccessful() && response.body() != null && rideAssistant != null) {
                        rideAssistant.setDangerAreas(response.body());
                    }
                }

                @Override
                public void onFailure(Call<List<DangerousArea>> call, Throwable ignored) {
                    // Existing ride tracking remains available when danger data cannot be refreshed.
                }
            });
        } catch (RuntimeException ignored) {
            // Keep the foreground service alive even if the legacy server client is unavailable.
        }
    }
}
