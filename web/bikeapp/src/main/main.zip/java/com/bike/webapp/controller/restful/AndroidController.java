package com.bike.webapp.controller.restful;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


import org.apache.commons.io.IOUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.bike.webapp.dto.AnLogin;
import com.bike.webapp.dto.App_RidingRecord;
import com.bike.webapp.dto.Course;
import com.bike.webapp.dto.LoginInfo;
import com.bike.webapp.dto.RidingRecord;
import com.bike.webapp.dto.*;
import com.bike.webapp.service.AndroidService;
import com.bike.webapp.service.MemberService;
import com.bike.webapp.service.*;


@Controller
@RequestMapping(value = "/app/")
public class AndroidController {
	
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@Value("${trailgo.storage-root}")
	private String storageRoot;
	
	//회원 Service객체
	@Autowired
	MemberService memberService;

	//앱 Service객체
	@Autowired
	AndroidService androidService;

	//라이딩 Service객체
	@Autowired
	private RidingService ridingService;
	
	//로그인
	@RequestMapping(value = "login")
	public @ResponseBody AnLogin login(@RequestBody AnLogin login) throws Exception {
		
		int list = androidService.LoginProcess(login);
		
		log.info("로그인결과카운트",list);
		if(list == 0) {
			login.setStatus("false");
		}
		else {
			login.setStatus("true");
		}
		return login;
	}
	
	//사용자 정보 가져오기
	@RequestMapping(value = "getLoginInfo/{LoginId}")
	public @ResponseBody LoginInfo getLoginInfo(@PathVariable String LoginId) throws Exception{
		return androidService.getLoginInfo(LoginId);
	}

	// 주행기록 등록(안드로이드)
	@RequestMapping(value = "riding/upload", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Map<String, String>> insertriding(@ModelAttribute RidingRecord record) {
		Map<String, String> result = new HashMap<String, String>();
		try {
			androidService.insertRecord(record); //기록저장
			result.put("saved", "1");
			return ResponseEntity.ok(result);
		}catch(Exception e) {
			log.error("Riding record save failed for rider={}", record.getRr_rider(), e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	//메인화면 라이딩 기록 가져오기
	@RequestMapping(value = "get/admin")
	public @ResponseBody List<App_RidingRecord> getRidingRecord() throws Exception {
		return androidService.readRecord("admin");
	}

	//주행기록 상세보기
	@RequestMapping(value = "get/detail/1")
	public @ResponseBody List<RidingRecord> getRidingRecordDetail() throws Exception {
		RidingRecord record = new RidingRecord();
		return androidService.getRidingRecordDetail("admin", "1");
	}
	
	//주행기록 공개여부 설정
		@RequestMapping(value = "recordset/open", method = RequestMethod.POST)
		public @ResponseBody Map<String, String> RidingOpenSet(HttpServletRequest request) throws Exception {
			RidingRecord record = new RidingRecord();
			record.setRr_num(Integer.parseInt(request.getParameter("rr_num")));
			record.setRr_open(Integer.parseInt(request.getParameter("rr_open")));
			System.out.println(request.getParameter("rr_num")+ " "+request.getParameter("rr_open"));

			int updated = androidService.RidingOpenSet(record);
			// 안드로이드에게 전달하는 데이터
			Map<String, String> result = new HashMap<String, String>();
			result.put("updated", String.valueOf(updated));

			return result;
		}
	
		//GPX파일 저장
		@RequestMapping(value = "fileUpload/{dir}/{fileName}", method = RequestMethod.POST)
		public ResponseEntity<Void> upload(HttpServletRequest request, MultipartFile file1, @PathVariable(value = "dir") String dir,
				@PathVariable(value="fileName") String fileName) {
			log.debug("업로드 파일 명 "+fileName+" "+"업로드 경로 "+dir);
			try {
				Path directory = resolveStorageDirectory(dir);
				if (file1 == null || file1.isEmpty()) {
					return ResponseEntity.badRequest().build();
			}
			Files.createDirectories(directory);
			try (InputStream input = file1.getInputStream()) {
				Files.copy(input, resolveStorageFile(directory, fileName), StandardCopyOption.REPLACE_EXISTING);
			}
			return ResponseEntity.ok().build();
			} catch (IOException e) {
				log.error("GPX upload failed: {}", fileName, e);
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
			}
		}

	// 코스 조회
	@RequestMapping(value = "riding/course")
	public @ResponseBody List<App_RidingRecord> getCourse() throws Exception {
		return androidService.getCourse();
	}

	// 코스 조회
	@RequestMapping(value = "riding/course/{c_num}")
	public @ResponseBody List<Course> getCourseItem(@PathVariable(value = "c_num") String c_num) throws Exception {
		System.out.println(c_num);
		return androidService.getCourseItem(c_num);
	}

	// 코스 스크랩하기
	@RequestMapping(value = "riding/coursescrap")
	public @ResponseBody Map<String, String> coursescrap(HttpServletRequest request) throws Exception {
		Scrap_Status scrap = new Scrap_Status();
		scrap.setSs_rnum(Integer.parseInt(request.getParameter("c_num")));
		scrap.setSs_rider(request.getParameter("ss_rider"));
		
		androidService.insertScrap(scrap);

		Map<String, String> result = new HashMap<String, String>();
		result.put("Status", "Ok");

		return result;
	}

	// 사용자 스크랩 코스 조회
	@RequestMapping(value = "riding/scrap/{rr_rider}")
	public @ResponseBody List<Scrap_Status> getScrap(@PathVariable(value = "rr_rider") String rr_rider) throws Exception {
		return androidService.getScrap(rr_rider);
	}

	// 사용자 스크랩 코스 상세보기
	@RequestMapping(value = "riding/scrap/{rr_rider}/{ss_course}", method = RequestMethod.GET)
	public @ResponseBody List<Course> getScrapDetail(@PathVariable(value = "rr_rider") String rr_rider,
			@PathVariable(value = "ss_course") String ss_course) throws Exception {
		return androidService.getScrapDetail(rr_rider, ss_course);
	}
	
	//스크랩 삭제
	@RequestMapping(value = "riding/scrap/del/{ss_rnum}", method = RequestMethod.GET)
	public void delScrap(@PathVariable(value = "ss_rnum") String ss_rnum) throws Exception {
		System.out.println(ss_rnum);
		androidService.delScrap(ss_rnum);
		
	}

	//좋아요
	@RequestMapping(value = "riding/course/like", method = RequestMethod.POST)
	public @ResponseBody  Map<String, String> likeput(HttpServletRequest request) throws Exception {
		System.out.println(request.getParameter("rr_rider") + " " +request.getParameter("rr_num"));
		RidingRecord record = new RidingRecord();
		record.setRr_rider(request.getParameter("rr_rider"));
		record.setRr_num(Integer.parseInt(request.getParameter("rr_num")));
		androidService.insertLike(record);
		Map<String, String> result = new HashMap<String, String>();
		result.put("Status", "Ok");

		return result;
	}
	
	//좋아요 읽기
	@RequestMapping(value = "riding/course/like/{rr_num}", method = RequestMethod.GET)
	public @ResponseBody List<RidingRecord> getLikeCount(@PathVariable(value = "rr_num") int rr_num) throws Exception {
		return androidService.getLikeCount(rr_num);
	}
	
	//좋아요 상태
		@RequestMapping(value = "riding/course/like/{ls_rnum}/{ls_rider}", method = RequestMethod.GET)
		public @ResponseBody List<Like_Status> getLikeStatus(@PathVariable(value = "ls_rnum") int ls_rnum, @PathVariable(value = "ls_rider") String ls_rider) throws Exception {
			return androidService.getLikeStatus(ls_rnum, ls_rider);
		}
		
	// 파일 다운로드
	@RequestMapping(value = "getGPX/{file_dir}/{file_name}", method = RequestMethod.GET)
	public ResponseEntity<byte[]> getImageAsResponseEntity( @PathVariable("file_name") String fileName, @PathVariable("file_dir") String fileDir ) throws IOException {
		Path file = resolveStorageFile(resolveStorageDirectory(fileDir), fileName);
		if (!Files.isRegularFile(file)) {
			return ResponseEntity.notFound().build();
		}

		HttpHeaders headers = new HttpHeaders();
		headers.setCacheControl(CacheControl.noCache().getHeaderValue());
		return new ResponseEntity<>(Files.readAllBytes(file), headers, HttpStatus.OK);
	}

	private Path resolveStorageDirectory(String directory) throws IOException {
		if (directory == null || !directory.matches("[A-Za-z0-9_-]+")) {
			throw new IOException("Invalid storage directory");
		}
		Path root = Paths.get(storageRoot).toAbsolutePath().normalize();
		Path resolved = root.resolve(directory).normalize();
		if (!resolved.startsWith(root)) {
			throw new IOException("Invalid storage directory");
		}
		return resolved;
	}

	private Path resolveStorageFile(Path directory, String fileName) throws IOException {
		if (fileName == null || !fileName.matches("[A-Za-z0-9._-]+")) {
			throw new IOException("Invalid storage file name");
		}
		Path file = directory.resolve(fileName).normalize();
		if (!file.startsWith(directory)) {
			throw new IOException("Invalid storage file name");
		}
		return file;
	}

	// 웹뷰용 라이딩 기록
	@RequestMapping(value = "getRidingRecord")
	public String getAppRidingRecord() {
		return "riding/appRidingRecord";
	}
	
	// 경쟁전 조회
	@RequestMapping(value = "competition")
	public @ResponseBody List<App_Competition> getCompetition() throws Exception {
		return androidService.getCompetition();
	}
	
	//경쟁전 참가내역 가져오기
	@RequestMapping(value = "competition/{rr_rider}")
	public @ResponseBody List<String> getjoinedComp(@PathVariable(value = "rr_rider") String rr_rider) throws Exception {
		return androidService.getjoinedComp(rr_rider);
	}

	// 경쟁전 코스 정보
	@RequestMapping(value = "getAppCompCourse")
	public String getAppCompCourse() {
		return "entertainment/appCompCourse";
	}
	
	// C_NUM으로 GPX파일 조회
	@RequestMapping(value="/getCompCourse", method = RequestMethod.GET)
	@ResponseBody
	public Gpx getCompCourse(int c_num) throws Exception {
		String gpxFile = androidService.getCompCourse(c_num);
		Gpx gpx = new Gpx();
		makeGpx(gpx, gpxFile);
		return gpx;
	}
	
	private void makeGpx(Gpx gpx, String gpxFile) throws Exception {
	
		String path = "/volume1/Develop/bikeapp/uploads/data/gpx/" + gpxFile;
		File file = new File(path);
		String txt = "";
		FileInputStream fis = new FileInputStream(file); 
		while(true) { 
			int res = fis.read(); 
			if(res<0) { 
				break; 
			}else { 
				txt += ((char)res);
			}
		}
		fis.close();
		gpx.setting(txt);
	}
	

	
	@RequestMapping("getCompClub/{cs_comp}")
	public @ResponseBody List<CompClub> getCompClub( @PathVariable(value = "cs_comp") int cs_comp) throws Exception {
		return androidService.getCompClub(cs_comp);
	}
	
	//코스검색
	@RequestMapping("riding/CourseSearch")
	public String CourseSearch() throws Exception{
		return "android/Android_CourseSearch";
	}
	
	//위험지역 마커
	@RequestMapping("riding/danger")
	public @ResponseBody List<DangerousArea> RidingDanger() throws Exception {
		return androidService.getDanger();
	}

	@RequestMapping("getCompBadge/{comp_badge}")
	public @ResponseBody Badge getCompBadge ( @PathVariable(value = "comp_badge") int comp_badge) throws Exception {
		return androidService.getCompBadge(comp_badge);
	}
	
	@RequestMapping("getCompScore/{comp_num}")
	public @ResponseBody List<CompScore> getCompScore ( @PathVariable("comp_num") int comp_num) throws Exception {
		return androidService.getCompScore(comp_num);
	}
	
	@RequestMapping(value = "/app/updateCompScore", method = RequestMethod.PUT)
	@ResponseBody
	public void updateCompScore(int avg_speed, int rr_comp, int r_club, String LoginId) throws Exception{

		androidService.updateCompScore(avg_speed, rr_comp, r_club, LoginId);
	}
	

	
	@RequestMapping(value = "updateRank", method = RequestMethod.PUT)
	@ResponseBody
	public void updateRank (int rr_comp, int r_club, int score, int rank) throws Exception {
		androidService.updateRank(rr_comp, r_club, score, rank);
	}
	
	@RequestMapping(value = "getMissionStatus/{LoginId}")
	public @ResponseBody List<Mission_Status> getMissionStatus ( @PathVariable(value="LoginId") String LoginId ) throws Exception {
		return androidService.getMissionStatus(LoginId);
	}
	
	@RequestMapping(value = "getNoClearMission/{LoginId}")
	public @ResponseBody List<Mission> getNoClearMission ( @PathVariable(value="LoginId") String LoginId ) throws Exception {
		return androidService.getNoClearMission(LoginId);
	}
	
	@RequestMapping(value = "updateMissionStatus", method = RequestMethod.PUT)
	@ResponseBody
	public void updateMissionStatus ( String LoginId, int typeScore1, int typeScore2 ) throws Exception {
		androidService.updateMissionStatus(LoginId, typeScore1, typeScore2);
	}
	
	@ResponseBody
	public void insertMissionCom ( String LoginId, int mc_mission, Timestamp mc_time ) throws Exception {
		androidService.insertMissionCom(LoginId, mc_mission, mc_time);
	}
	
	@RequestMapping(value="riding/getrecord")
	@ResponseBody
	public  List<RidingRecord>getRecord () throws Exception {
		return androidService.selectRecord();
	}
	
	@RequestMapping(value="riding/taginsert")
	@ResponseBody
	public Map<String, String>  Taginsert(HttpServletRequest request) {

		System.out.println(request.getParameter("rr_num") + " " + request.getParameter("rr_rider") + " " + request.getParameter("address_dong"));

		App_Tag tag = new App_Tag();
		tag.setTs_rnum(Integer.parseInt(request.getParameter("rr_num")));
		tag.setTs_rider(request.getParameter("rr_rider"));
		tag.setTs_tag(request.getParameter("address_dong"));

		androidService.TagInsert(tag);
		// 안드로이드에게 전달하는 데이터
		Map<String, String> result = new HashMap<>();
		result.put("data1", "성공했쩡");
		return result;
	}
	
	@RequestMapping(value = "getAllMission/{LoginId}")
	public @ResponseBody List<App_Mission> getAllMission ( @PathVariable(value="LoginId") String LoginId) throws Exception {
		return androidService.getAllMission(LoginId);
	}
	
	@RequestMapping(value = "getComMission/{LoginId}")
	public @ResponseBody List<String> getComMission ( @PathVariable(value="LoginId") String LoginId) throws Exception {
		return androidService.getComMission(LoginId);
	}
	
	@RequestMapping(value = "getWhenCom/{LoginId}/{m_num}")
	public @ResponseBody Date getWhenCom ( @PathVariable(value="LoginId") String LoginId,
												@PathVariable(value="m_num") int m_num) throws Exception {
		return androidService.getWhenCom(LoginId, m_num);
	}
	
	@RequestMapping(value = "getMisRanking")
	public @ResponseBody List<App_MissionRanking> getMisRanking () throws Exception {
		return androidService.getMisRanking();
	}
	
	@RequestMapping(value = "getCourseReview/{c_num}")
	public @ResponseBody List<App_CourseReview> getCourseRiview (@PathVariable(value="c_num") int c_num) throws Exception{
		return androidService.getCourseRiview(c_num);
	}

	@RequestMapping("riding/course_view/{rr_num}")
	public String course_view(@PathVariable int rr_num, Model model) throws Exception{
		model.addAttribute("rr_num", rr_num);
		return "android/course_view";
	}

	@RequestMapping("riding/course_share/{rr_num}")
	public String course_share(@PathVariable int rr_num, Model model) throws Exception{
		model.addAttribute("rr_num", rr_num);
		return "android/course_share";
	}

	
	//RR_NUM으로 RIDINGRECORD 조회
	@RequestMapping(value="/getRidingRecordByRR_Num/{rr_num}", method = RequestMethod.GET)
	@ResponseBody
	public RidingRecord getRidingRecordByRR_Num(@PathVariable int rr_num, Model model) throws Exception {
		RidingRecord rr = ridingService.getRidingRecordDetail(rr_num);
		int like = ridingService.getRR_Like(rr_num);
		rr.setRr_like(like);
		return rr;
	}

	@RequestMapping(value = "riding/foup")
	// 주소변경예정 @RequestMapping(value = "/android/recordInsert")
	@ResponseBody
	public Map<String, String> insertFollowRiding(HttpServletRequest request) throws Exception {
		RidingRecord record = new RidingRecord();

		// 현재날짜 timestamp
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		// formatter.setTimeZone(TimeZone.getTimeZone("GMT+09"));
		Calendar cal = Calendar.getInstance();
		String today = null;
		today = formatter.format(cal.getTime());
		Timestamp ts = Timestamp.valueOf(today);
		record.setRr_rider(request.getParameter("rr_rider"));
		record.setRr_date(ts);
		record.setRr_distance(Integer.parseInt(request.getParameter("rr_distance")));
		record.setRr_topspeed(Integer.parseInt(request.getParameter("rr_topspeed")));
		record.setRr_avgspeed(Integer.parseInt(request.getParameter("rr_avgspeed")));
		record.setRr_high(Integer.parseInt(request.getParameter("rr_high")));
		record.setRr_gpx(request.getParameter("rr_gpx"));
		record.setRr_open(Integer.parseInt(request.getParameter("rr_open")));
		record.setRr_breaktime(Integer.parseInt(request.getParameter("rr_breaktime")));
		record.setRr_time(Integer.parseInt(request.getParameter("rr_time")));
		record.setRr_area(request.getParameter("rr_area"));
		record.setRr_name(request.getParameter("rr_name"));
		record.setRr_foname(request.getParameter("rr_name"));
		// 안드로이드에게 전달하는 데이터
		Map<String, String> result = new HashMap<String, String>();
		result.put("data1", request.getParameter("rr_rider"));
		androidService.foinsert(record);
		androidService.foupdate(record);
		return result;
	}
	
	@RequestMapping(value = "updateCourseReview")
	@ResponseBody
	public void updateCourseReview(HttpServletRequest request) throws Exception {
		App_CourseReview C_review = new App_CourseReview();

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String today = null;
		today = formatter.format(cal.getTime());
		Timestamp ts = Timestamp.valueOf(today);

		C_review.setCr_content(request.getParameter("cr_content"));
		C_review.setCr_images(request.getParameter("cr_image"));
		C_review.setCr_num(Integer.parseInt(request.getParameter("cr_num")));
		C_review.setCr_time(ts);
		androidService.updateCourseReview(C_review);
	}

	@RequestMapping(value = "insertCourseReview")
	@ResponseBody
	public void insertCourseReview(HttpServletRequest request) throws Exception {
		App_CourseReview C_review = new App_CourseReview();

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		String today = null;
		today = formatter.format(cal.getTime());
		Timestamp ts = Timestamp.valueOf(today);

		C_review.setCr_content(request.getParameter("cr_content"));
		C_review.setCr_images(request.getParameter("cr_image"));
		C_review.setCr_time(ts);
		C_review.setCr_rider(request.getParameter("cr_rider"));
		C_review.setCr_rnum(Integer.parseInt(request.getParameter("cr_rnum")));
		androidService.insertCourseReview(C_review);
	}

	@RequestMapping(value = "deleteCourseReview")
	@ResponseBody
	public void deleteCourseReview(HttpServletRequest request) throws Exception {
		String cr_num = "";

		cr_num = request.getParameter("cr_num");

		androidService.deleteCourseReview(cr_num);
	}

	@RequestMapping(value = "sameCheck/{id}")
	@ResponseBody
	public String sameCheck(@PathVariable(value = "id") String id) throws Exception {
		int response;

		response = androidService.sameCheck(id);

		if (response == 0)
			return "ok";
		else
			return "no";
	}
	
	@RequestMapping(value = "insertreg")
	@ResponseBody
	public void insertReg(HttpServletRequest request) throws Exception {
		Member member  = new Member();
		
		member.setR_id(request.getParameter("id"));
		member.setR_pw(request.getParameter("pw"));
		member.setR_name(request.getParameter("name"));
		member.setR_nickname(request.getParameter("nickname"));	
		member.setR_birth(request.getParameter("birth"));
		member.setR_phone(request.getParameter("phone"));
		member.setR_gender(request.getParameter("gender"));
		member.setR_addr(request.getParameter("addr1"));
		member.setR_addr2(request.getParameter("addr2"));
		member.setR_type(request.getParameter("type"));
		member.setR_image(request.getParameter("image"));

		memberService.memberInsert(member);
	}

	// 사용자 등록 위험 지역 조회
	@RequestMapping(value = "danger/{rr_rider}")
	public @ResponseBody List<DangerousArea> getUserDangerousArea(@PathVariable(value="rr_rider") String rr_rider) throws Exception {
		return ridingService.getUserDangerousArea(rr_rider);
	}
	
	//위험지역 등록하기
	@RequestMapping(value = "insertDanger")
	public @ResponseBody void insertDanger(@RequestBody DangerousArea d_area) throws Exception{
		
		androidService.insertDanger(d_area);
	}

	//긴급 위치알림
	@RequestMapping(value = "dangergps/{lat}/{lon}")
	public  String dangerGps(Model model, @PathVariable(value="lat") String lat, @PathVariable(value="lon") String lon) throws Exception {
	model.addAttribute("lat",lat);
	model.addAttribute("lon",lon);
		return "android/helpgps";
	}
}
